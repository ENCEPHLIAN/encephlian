# encephlian-core

Canonicalization (C-Plane) and Inference (I-Plane) core for ENCEPHLIAN / MIND.

This repository defines:
- Canonical EEG schema
- Deterministic pipelines
- Validator gates
- CLI workers for C-Plane and I-Plane
