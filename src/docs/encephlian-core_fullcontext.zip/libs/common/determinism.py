from __future__ import annotations

def deterministic_created_utc(input_signature: str) -> str:
    """
    Deterministic surrogate for created_utc to keep derivative trees byte-stable.
    We do NOT encode wall-clock time in v1 derivatives because it breaks idempotency.
    """
    # 16 chars is enough uniqueness for run-to-run determinism, still human-readable.
    return (input_signature or "")[:16]
