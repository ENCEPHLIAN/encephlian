import json
import sys
from pathlib import Path

import zarr
from jsonschema import Draft202012Validator

SCHEMA_PATH = Path(__file__).resolve().parents[2] / "schemas" / "canonical_meta.schema.json"

def _err(msg: str) -> None:
    print(msg, file=sys.stderr)

def validate_meta(meta_path: Path) -> dict:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    v = Draft202012Validator(schema)
    errors = sorted(v.iter_errors(meta), key=lambda e: e.path)
    if errors:
        for e in errors[:25]:
            loc = ".".join([str(x) for x in e.path]) if e.path else "<root>"
            _err(f"[META INVALID] {loc}: {e.message}")
        raise SystemExit(2)
    return meta

def validate_tensor(meta_path: Path, meta: dict) -> None:
    base = meta_path.parent
    tensor_rel = meta.get("tensor", {}).get("path", "tensor.zarr")
    tensor_path = (base / tensor_rel).resolve()

    if not tensor_path.exists():
        _err(f"[TENSOR MISSING] expected at {tensor_path}")
        raise SystemExit(3)

    store = zarr.DirectoryStore(str(tensor_path))
    root = zarr.open(store=store, mode="r")

    if "X" not in root:
        _err("[TENSOR INVALID] dataset 'X' not found in tensor.zarr")
        raise SystemExit(3)

    X = root["X"]
    n_channels = int(meta["n_channels"])
    n_samples = int(meta["n_samples"])

    if tuple(X.shape) != (n_channels, n_samples):
        _err(f"[TENSOR SHAPE MISMATCH] X.shape={X.shape} meta=({n_channels},{n_samples})")
        raise SystemExit(3)

    if str(X.dtype) != "float32":
        _err(f"[TENSOR DTYPE MISMATCH] X.dtype={X.dtype} expected float32")
        raise SystemExit(3)

def main() -> None:
    if len(sys.argv) != 2:
        _err("Usage: enceph-validate /path/to/meta.json")
        raise SystemExit(1)

    meta_path = Path(sys.argv[1]).expanduser().resolve()
    if not meta_path.exists():
        _err(f"meta.json not found: {meta_path}")
        raise SystemExit(1)

    meta = validate_meta(meta_path)
    validate_tensor(meta_path, meta)
    print("OK: canonical meta + tensor conform to v1 contract")

if __name__ == "__main__":
    main()
