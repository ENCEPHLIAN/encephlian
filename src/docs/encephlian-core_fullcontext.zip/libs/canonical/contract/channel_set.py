CANONICAL_CHANNELS = [
    "FP1","FP2","F3","F4","C3","C4",
    "P3","P4","O1","O2",
    "F7","F8","T3","T4","T5","T6",
    "FZ","CZ","PZ",
    "A1","A2",
    "T1","T2",
    "PG1","PG2",
    "EKG","PHOTIC"
]
