from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import zarr

def load_meta(v1_dir: Path) -> dict:
    return json.loads((v1_dir / "meta.json").read_text(encoding="utf-8"))

def open_tensor(v1_dir: Path):
    store = zarr.DirectoryStore(str(v1_dir / "tensor.zarr"))
    root = zarr.open(store=store, mode="r")
    return root["X"]

def open_artifact_mask(v1_dir: Path):
    store = zarr.DirectoryStore(str(v1_dir / "derivatives" / "artifact_mask.zarr"))
    root = zarr.open(store=store, mode="r")
    return root["mask"]

def read_window(X, start: int, length: int) -> np.ndarray:
    start = int(max(0, start))
    end = int(min(X.shape[1], start + int(length)))
    return np.asarray(X[:, start:end], dtype=np.float32)

def read_mask_window(mask, start: int, length: int) -> np.ndarray:
    start = int(max(0, start))
    end = int(min(mask.shape[0], start + int(length)))
    return np.asarray(mask[start:end], dtype=np.uint8)
