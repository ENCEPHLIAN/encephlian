# C-Plane Schemas (MVP)

Canonical data is immutable. Derived outputs are append-only, referenced via derived/current.json (Option B).

## Canonical
- meta.json: study-level metadata (sampling rate, channel names/map, etc.)
- signals.zarr/: canonical EEG signal array (planar storage)

## Derived (I-plane output)
Path convention:
data/studies/<study_id>/derived/<model_id>/<model_version>/<run_id>/
  - segments.json
  - artifacts.json
  - annotations.json
  - manifest.json

Pointer:
data/studies/<study_id>/derived/current.json
  - {study_id, model_id, model_version, run_id, canon_hash?, params_hash?, created_utc?}

## segments.json (cplane.segments.v1)
- schema_version: "cplane.segments.v1"
- study_id: string
- run_id: string | null
- segments: list of:
  - start_sec: number
  - end_sec: number | null
  - label: string
  - confidence: number (0..1)

