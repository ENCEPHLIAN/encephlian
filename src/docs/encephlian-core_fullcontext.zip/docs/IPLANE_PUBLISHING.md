# I-Plane Publishing (MVP)

## Goals
- Deterministic
- Idempotent
- Append-only derived outputs
- Read API serves derived via Option B pointer.

## run_id
run_id must be stable for identical canonical inputs + params + model version.
(Implementation in apps/infer/core/run_id.py.)

## Publish protocol
1) Compute canon_hash and params_hash
2) Compute run_id
3) Write derived outputs to:
   derived/<model_id>/<model_version>/<run_id>/
4) Update derived/current.json to point to that run

## Read API behavior
/segments reads derived/current.json and serves the pointed segments.json.
