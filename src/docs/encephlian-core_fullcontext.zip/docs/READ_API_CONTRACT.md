# READ API Contract (MVP)

This contract is immutable for MVP: TUH_CANON_001 only.

## Auth
All endpoints under /studies/* require header:
- x-api-key: <ENCEPH_API_KEY>
(Also accepts X-API-KEY for compatibility.)

## Endpoints

### GET /health
- 200 JSON: {"ok":true,"root":"<path>"}

### GET /studies/{study_id}/meta?root=.
- 200 JSON meta for the study.
- 404 if study_id != TUH_CANON_001 (MVP lock).

### GET /studies/{study_id}/chunk.bin?start=<int>&length=<int>&root=.
Returns binary planar float32 chunk:
- Layout: planar [n_channels][length], little-endian float32
- Media-Type: application/octet-stream
- Deterministic content hash: x-eeg-content-sha256 (sha256 of body bytes)

Required response headers (must be CORS-exposed):
- x-eeg-study-id
- x-eeg-start
- x-eeg-length
- x-eeg-sample-rate-hz
- x-eeg-channel-count
- x-eeg-channel-ids (CSV)
- x-eeg-samples-per-channel
- x-eeg-layout (planar)
- x-eeg-dtype (f32le)
- x-eeg-unit (uV)
- x-eeg-content-sha256
- x-eeg-server-ms
- etag
- cache-control (public, max-age=31536000, immutable)

### GET /studies/{study_id}/segments?root=.
Option B publishing:
- If derived/current.json exists: serve derived/<model_id>/<model_version>/<run_id>/segments.json
- Otherwise: return empty cplane.segments.v1 with run_id=null

### GET /studies/{study_id}/artifacts?root=.
MVP: serve artifacts.json (canonical) or derived later (future extension).

### GET /studies/{study_id}/annotations?root=.
MVP: serve annotations.json (canonical) or derived later (future extension).

## CORS
CORS must expose x-eeg-* headers used by browser clients.

