# Canonical EEG Study Contract (v1.0.0)

A CanonicalEEGStudy is the only legal handoff between planes.

## Layout
studies/{study_id}/canonical/v1/
- tensor.zarr/         (signal geometry only; float32; units uV; shape [channels, time])
- meta.json            (truth table + contract)
- derivatives/         (optional)
- audit.jsonl          (append-only stage logs)

## Principles
- Deterministic > complete. If unknown: null + reason in missingness_flags.
- Vendor formats never reach I-Plane or Experience Plane.
- Tensor contains samples only; all semantics live in meta/derivatives.
- Same input + same converter_version => identical outputs.

## Required meta.json fields
See schemas/canonical_meta.schema.json.
