# MVP Freeze Checklist (TUH_CANON_001)

## A. Backend (Local)
- [ ] uvicorn runs locally
- [ ] /health returns 200
- [ ] /meta returns 200 with X-API-KEY
- [ ] /chunk returns 200 with X-API-KEY for multiple windows
- [ ] /chunk semantics: start/length are samples; raw is immutable

## B. Backend (Docker)
- [ ] docker build succeeds (COPY libs before pip install .)
- [ ] docker run starts and /health 200
- [ ] docker curl to /meta and /chunk works (with X-API-KEY)
- [ ] container contains dataset at /app/data/studies/TUH_CANON_001

## C. Frontend (Lovable)
- [ ] No hook-order errors (no conditional hooks)
- [ ] On first load: waveform is visible (no flatline)
- [ ] Windowed fetch tied to player time
- [ ] Seek/play causes deterministic fetches
- [ ] Overlay toggle does not affect gain/amplitude
- [ ] Suppression toggle affects only display, not raw buffers

## D. Deployment (Azure)
- [ ] Read API deployed as container with HTTPS
- [ ] VITE_ENCEPH_READ_API_BASE points to Azure
- [ ] X-API-KEY header is always included in viewer requests
