#!/usr/bin/env bash
set -euo pipefail

# ---- User-editable defaults (override via env) ----
: "${RG:=enceph-mvp-rg}"
: "${APP:=enceph-readapi}"
: "${ACR:=enceph}"
: "${IMAGE_REPO:=enceph-readapi}"
: "${PORT:=8787}"
: "${FQDN:=}"               # optional override
: "${API_KEY:=}"            # required for smoke tests
: "${STUDY_ID:=TUH_CANON_001}"
: "${READ_API_ROOT:=.}"

# ---- Derived ----
SHA="$(git rev-parse --short HEAD)"
TAG="tuh-amd64-${SHA}"
IMAGE="${ACR}.azurecr.io/${IMAGE_REPO}:${TAG}"

echo "==> Building + pushing image (linux/amd64): ${IMAGE}"
az acr login -n "${ACR}" >/dev/null

# Ensure buildx exists and is selected
docker buildx create --use --name encephbuilder >/dev/null 2>&1 || true

docker buildx build \
  --platform linux/amd64 \
  -f apps/read_api/Dockerfile \
  -t "${IMAGE}" \
  --push \
  .

echo "==> Updating Container App to image: ${IMAGE}"
# Prefer az containerapp update if available; fallback to az rest.
if az containerapp update -g "${RG}" -n "${APP}" --image "${IMAGE}" >/dev/null 2>&1; then
  :
else
  echo "WARN: az containerapp update failed; falling back to az rest patch"
  SUB="$(az account show --query id -o tsv)"
  az rest --method patch \
    --url "https://management.azure.com/subscriptions/${SUB}/resourceGroups/${RG}/providers/Microsoft.App/containerApps/${APP}?api-version=2025-01-01" \
    --body "{\"properties\":{\"template\":{\"containers\":[{\"name\":\"${APP}\",\"image\":\"${IMAGE}\"}]}}}" >/dev/null
fi

echo "==> Waiting for latest revision to be Healthy..."
for i in {1..40}; do
  # Pull revision list; find top row with Active=True and TrafficWeight=100 if possible
  if az containerapp revision list -g "${RG}" -n "${APP}" -o json >/tmp/ca_revs.json 2>/dev/null; then
    HEALTH="$(python3 - <<'PY'
import json
revs=json.load(open("/tmp/ca_revs.json"))
# pick active with highest traffic
best=None
for r in revs:
    tw=r.get("trafficWeight",0)
    if r.get("active") and (best is None or tw>best.get("trafficWeight",0)):
        best=r
if best is None:
    print("UNKNOWN"); exit()
print(best.get("healthState","UNKNOWN"))
PY
)"
    if [[ "${HEALTH}" == "Healthy" ]]; then
      echo "==> Healthy ✅"
      break
    fi
  fi
  sleep 3
  if [[ $i -eq 40 ]]; then
    echo "ERROR: did not reach Healthy in time. Check:"
    echo "  az containerapp revision list -g ${RG} -n ${APP} -o table"
    exit 1
  fi
done

# Resolve FQDN if not set
if [[ -z "${FQDN}" ]]; then
  FQDN="$(az containerapp show -g "${RG}" -n "${APP}" --query properties.configuration.ingress.fqdn -o tsv 2>/dev/null || true)"
fi
if [[ -z "${FQDN}" ]]; then
  echo "ERROR: Could not resolve FQDN."
  exit 1
fi

echo "==> FQDN: https://${FQDN}"

if [[ -z "${API_KEY}" ]]; then
  echo "NOTE: API_KEY not set; skipping authenticated smoke tests."
  echo "      Run: API_KEY='...' RG='...' APP='...' scripts/deploy_readapi_azure.sh"
  exit 0
fi

echo "==> Running smoke tests..."
scripts/smoke_readapi.sh "https://${FQDN}" "${API_KEY}" "${STUDY_ID}" "${READ_API_ROOT}"
echo "==> Deploy + smoke complete ✅"
