#!/usr/bin/env bash
set -euo pipefail

BASE="${1:?base url required, e.g. https://...}"
KEY="${2:?api key required}"
STUDY="${3:-TUH_CANON_001}"
ROOT="${4:-.}"

tmp_hdr="$(mktemp)"
trap 'rm -f "$tmp_hdr"' EXIT

echo "SMOKE: base=${BASE} study=${STUDY}"

echo "==> health"
curl -fsS "${BASE}/health" | head -200
echo

echo "==> meta"
curl -fsS -o /dev/null -w "meta:%{http_code}\n" \
  -H "x-api-key: ${KEY}" \
  "${BASE}/studies/${STUDY}/meta?root=${ROOT}"

echo "==> chunk headers (start=0 length=256)"
curl -fsS -D "$tmp_hdr" -o /dev/null \
  -H "x-api-key: ${KEY}" \
  "${BASE}/studies/${STUDY}/chunk.bin?start=0&length=256&root=${ROOT}"

# Print top headers for visibility
sed -n '1,60p' "$tmp_hdr"
echo

# ---- Assertions ----
# Disallow legacy headers
if awk 'BEGIN{IGNORECASE=1} /^x-eeg-(samplerate|nchannels):/ {exit 1} END{exit 0}' "$tmp_hdr"; then
  :
else
  echo "ERROR: legacy headers present (x-eeg-samplerate / x-eeg-nchannels)."
  exit 1
fi

# Ensure required headers exist exactly once
require_once () {
  local h="$1"
  local n
  n="$(awk -v H="$h" 'BEGIN{IGNORECASE=1; c=0} $0 ~ ("^"H":") {c++} END{print c}' "$tmp_hdr")"
  if [[ "$n" != "1" ]]; then
    echo "ERROR: header ${h} count=${n} (expected exactly 1)"
    exit 1
  fi
}

require_once "x-eeg-study-id"
require_once "x-eeg-start"
require_once "x-eeg-length"
require_once "x-eeg-sample-rate-hz"
require_once "x-eeg-channel-count"
require_once "x-eeg-channel-ids"
require_once "x-eeg-samples-per-channel"
require_once "x-eeg-layout"
require_once "x-eeg-dtype"
require_once "x-eeg-unit"
require_once "x-eeg-content-sha256"
require_once "x-eeg-server-ms"
require_once "etag"
require_once "cache-control"

# Ensure dtype is canonical
dtype="$(awk 'BEGIN{IGNORECASE=1} /^x-eeg-dtype:/ {gsub("\r","",$2); print $2; exit}' "$tmp_hdr")"
if [[ "$dtype" != "f32le" ]]; then
  echo "ERROR: x-eeg-dtype=${dtype} (expected f32le)"
  exit 1
fi

# Ensure etag matches content sha
sha="$(awk 'BEGIN{IGNORECASE=1} /^x-eeg-content-sha256:/ {gsub("\r","",$2); print $2; exit}' "$tmp_hdr")"
etag="$(awk 'BEGIN{IGNORECASE=1} /^etag:/ {gsub("\r","",$2); print $2; exit}' "$tmp_hdr")"
if [[ -z "$sha" || -z "$etag" || "$sha" != "$etag" ]]; then
  echo "ERROR: etag does not match x-eeg-content-sha256"
  echo "  sha=${sha}"
  echo "  etag=${etag}"
  exit 1
fi

echo "==> segments"
curl -fsS \
  -H "x-api-key: ${KEY}" \
  "${BASE}/studies/${STUDY}/segments?root=${ROOT}" | head -200
echo

echo "SMOKE: OK ✅"
