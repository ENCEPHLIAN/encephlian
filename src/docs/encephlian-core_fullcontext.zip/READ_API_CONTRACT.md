# ENCEPH Read API Contract (MVP Lock)

**Scope:** TUH_CANON_001 only. Single-study hard lock until MVP complete.

## 0) Non-negotiables
- **Determinism:** same request inputs MUST produce identical outputs (bytes + JSON ordering).
- **No full-file preload:** client requests only windowed chunks.
- **Binary is canonical:** chunk transport is `application/octet-stream` containing **Float32**.
- **Viewer correctness MUST NOT depend on header visibility** (proxies/CORS can strip). Headers are a best-effort convenience.
- **Auth + CORS are part of the contract** (browser must be able to call Read API from Experience Plane).

## 1) Base URLs
- Local: `http://127.0.0.1:8787`
- Azure (stable): `https://enceph-readapi.whitecoast-5be3fbc0.centralindia.azurecontainerapps.io`

## 2) Authentication
- Required header: `x-api-key: <token>`
- Server MAY also accept `X-API-KEY` for compatibility, but clients MUST use `x-api-key`.

Failure mode:
- Missing/invalid key → `401 Unauthorized`

## 3) CORS
Server MUST support browser access from the Experience Plane.

Required response behavior:
- `Access-Control-Allow-Origin: *` (MVP) OR allowlist production domains
- `Access-Control-Allow-Headers` includes: `x-api-key`, `content-type`
- `Access-Control-Expose-Headers` includes all `x-eeg-*` headers listed below (if provided)

## 4) Endpoints

### 4.1 Health
`GET /health`

Response: `200 OK`  
Content-Type: `application/json`  
Body:
- `status` MUST be `"ok"`.

Example body:
- `{ "status": "ok" }`

### 4.2 Study meta
`GET /studies/{study_id}/meta?root=.`

Path:
- `study_id` (string): MUST be `TUH_CANON_001` for MVP.

Query:
- `root` (string): default `"."` (MVP always uses `"."`)

Response: `200 OK`  
Content-Type: `application/json`

Body:
- MUST contain `meta` object OR be the `meta` object directly.
- Fields MUST be deterministic and stable.

Required meta fields (v1):
- `schema_version` (string): `cplane.meta.v1`
- `study_id` (string)
- `n_channels` (int)
- `sampling_rate_hz` (number)
- `n_samples` (int)
- `dtype` (string): `float32`
- `layout` (string): `unknown` | `channel-major` | `sample-major` (informational)
- `channel_map` (array): ordered by `index`; defines canonical channel order

Example:
- `{ "meta": { "schema_version": "cplane.meta.v1", "study_id": "TUH_CANON_001", "n_channels": 19, "sampling_rate_hz": 250, "n_samples": 1234567, "dtype": "float32", "layout": "unknown", "channel_map": [ { "index": 0, "canonical_id": "FP1", "unit": "uV" } ] } }`

### 4.3 Binary window chunk
`GET /studies/{study_id}/chunk.bin?root=.&start=<int>&length=<int>`

Query:
- `root` (string): default `"."`
- `start` (int): starting sample index (0-based)
- `length` (int): samples **per channel** in this window

Response: `200 OK`  
Content-Type: `application/octet-stream`

Body:
- Raw bytes encoding a **Float32** array (little-endian).
- Total number of float32 values MUST equal `n_channels * length`.
- Byte length MUST equal `n_channels * length * 4`.

Contract invariant:
- `byte_length == n_channels * length * 4`

Optional response headers (best-effort; DO NOT make client correctness depend on visibility):
- `x-eeg-nchannels: <int>`
- `x-eeg-length: <int>` (samples per channel)
- `x-eeg-sr: <int>` (Hz)
- `x-eeg-dtype: float32`
- `x-eeg-layout: channel-major|sample-major|unknown`
- `x-eeg-channel-ids: FP1,FP2,...` (comma-separated canonical IDs)
- `x-eeg-content-sha256: <hex>` (optional)

Failure modes:
- invalid params → `400`
- missing/invalid key → `401`

### 4.4 Derived artifacts
`GET /studies/{study_id}/artifacts?root=.`

Response: `200 OK`  
Content-Type: `application/json`

Required fields:
- `schema_version`: `cplane.artifacts.v1`
- `study_id`
- `run_id` (string or null)
- `artifacts` array

Artifact object fields:
- `start_sec` (number)
- `end_sec` (number)
- `label` (string or null)
- `channel` (int or null)

### 4.5 Derived annotations
`GET /studies/{study_id}/annotations?root=.`

Response: `200 OK`  
Content-Type: `application/json`

Required fields:
- `schema_version`: `cplane.annotations.v1`
- `study_id`
- `run_id` (string or null)
- `annotations` array

Annotation object fields:
- `start_sec` (number)
- `end_sec` (number or null)
- `label` (string or null)
- `channel` (int or null)

### 4.6 Derived segments (I-plane outputs)
`GET /studies/{study_id}/segments?root=.`

Response: `200 OK`  
Content-Type: `application/json`

Required fields:
- `schema_version`: `cplane.segments.v1`
- `study_id`
- `run_id` (string; MUST be non-null once I-plane is implemented)
- `segments` array

Segment object fields:
- `start_sec` (number)
- `end_sec` (number)
- `label` (string)
- `confidence` (number or null; 0..1)

## 5) Idempotency rules for I-plane publishing (next phase)
When I-plane writes derived JSON back into C-plane:
- `run_id` MUST be present and consistent across artifacts/annotations/segments for that run.
- Derived JSON MUST be byte-stable for identical inputs (`study_id`, `model_id`, `model_version`, `input_hash`).
- Client must be able to validate consistency by comparing `run_id` fields.

