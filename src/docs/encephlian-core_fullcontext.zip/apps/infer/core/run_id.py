import hashlib
import json
import os
from pathlib import Path
from typing import Any, Dict, Tuple

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def canonical_json(obj: Any) -> bytes:
    # Deterministic: sorted keys, no whitespace, UTF-8.
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha256_dir_tree(root: Path) -> str:
    # Deterministic directory hash:
    # - sort by relative path (C locale equivalent via Python ordering)
    # - hash (path + NUL + file_bytes_hash) lines into a final sha
    files = [p for p in root.rglob("*") if p.is_file()]
    files.sort(key=lambda p: str(p.relative_to(root)))
    h = hashlib.sha256()
    for p in files:
        rel = str(p.relative_to(root)).replace("\\", "/").encode("utf-8")
        fh = sha256_file(p).encode("utf-8")
        h.update(rel + b"\0" + fh + b"\n")
    return h.hexdigest()

def canon_hash(study_dir: Path) -> Dict[str, str]:
    meta_path = study_dir / "meta.json"
    zarr_dir = study_dir / "signals.zarr"
    if not meta_path.exists():
        raise FileNotFoundError(f"meta.json not found: {meta_path}")
    if not zarr_dir.exists():
        raise FileNotFoundError(f"signals.zarr not found: {zarr_dir}")

    meta_h = sha256_file(meta_path)
    zarr_h = sha256_dir_tree(zarr_dir)

    # Combined canon hash: stable string
    combined = (
        f"meta_sha256={meta_h}\n"
        f"signals_zarr_tree_sha256={zarr_h}\n"
    ).encode("utf-8")

    return {
        "meta_sha256": meta_h,
        "signals_zarr_tree_sha256": zarr_h,
        "canon_hash": sha256_bytes(combined),
    }

def params_hash(params: Dict[str, Any]) -> str:
    return sha256_bytes(canonical_json(params))

def compute_run_id(study_id: str, model_id: str, model_version: str, canon_hash_hex: str, params_hash_hex: str) -> str:
    s = (
        f"study_id={study_id}\n"
        f"model_id={model_id}\n"
        f"model_version={model_version}\n"
        f"canon_hash={canon_hash_hex}\n"
        f"params_hash={params_hash_hex}\n"
    ).encode("utf-8")
    return sha256_bytes(s)
