from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import zarr


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _sha256_file(p: Path) -> str:
    return _sha256_bytes(p.read_bytes())


def _safe_mkdir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def _atomic_write_text(path: Path, text: str) -> None:
    _safe_mkdir(path.parent)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=str(path.parent), encoding="utf-8") as f:
        f.write(text)
        tmp = Path(f.name)
    tmp.replace(path)


@dataclass(frozen=True)
class PublishConfig:
    root: Path
    study_id: str
    model_id: str
    model_version: str
    params: Dict[str, Any]


def _resolve_study_dir(root: Path, study_id: str) -> Path:
    # Support both layouts used in the repo history:
    # 1) <root>/data/studies/<study_id>
    # 2) <root>/studies/<study_id>
    candidates = [
        root / "data" / "studies" / study_id,
        root / "studies" / study_id,
        root / study_id,
    ]
    for p in candidates:
        if (p / "meta.json").exists() and (p / "signals.zarr").exists():
            return p
    raise FileNotFoundError(f"Study not found under root={root}. Tried: {candidates}")


def _open_signals(study_dir: Path) -> zarr.Array:
    zp = study_dir / "signals.zarr"
    g = zarr.open_group(str(zp), mode="r")
    if "signals" in g:
        return g["signals"]
    arrays = list(g.arrays())
    if not arrays:
        raise RuntimeError("signals.zarr contains no arrays")
    return arrays[0][1]


def compute_run_id(study_id: str, model_id: str, model_version: str, canon_hash: str, params_hash: str) -> str:
    payload = (
        f"study_id={study_id}\n"
        f"model_id={model_id}\n"
        f"model_version={model_version}\n"
        f"canon_hash={canon_hash}\n"
        f"params_hash={params_hash}\n"
    ).encode("utf-8")
    # Short but collision-safe enough for MVP; keep full in manifest.
    return hashlib.sha256(payload).hexdigest()[:16]


def _stats_features(arr: zarr.Array, win_samples: int = 4096) -> Tuple[List[float], List[float]]:
    # Deterministic: take the first window only (MVP), avoid randomness.
    n_ch = int(arr.shape[0])
    n_samp = int(arr.shape[1])
    end = min(win_samples, n_samp)
    x = np.asarray(arr[:, 0:end], dtype=np.float32)

    means = x.mean(axis=1).astype(np.float32).tolist()
    stds = x.std(axis=1).astype(np.float32).tolist()
    return means, stds


def _heuristic_segments(means: List[float], stds: List[float]) -> List[Dict[str, Any]]:
    # MVP heuristic (deterministic): flag channels with extreme std as "noisy".
    # This is intentionally simplistic; it proves publishing loop + UI overlays.
    segs: List[Dict[str, Any]] = []
    if not stds:
        return segs
    med = float(np.median(np.array(stds, dtype=np.float32)))
    thr = max(50.0, 5.0 * med)  # floor to avoid tiny medians
    for ch, s in enumerate(stds):
        if float(s) > thr:
            segs.append(
                {
                    "t_start_s": 0.0,
                    "t_end_s": 10.0,
                    "label": "noisy_channel",
                    "channel_index": int(ch),
                    "score": float(s / (thr + 1e-6)),
                }
            )
    return segs


def publish(cfg: PublishConfig) -> Dict[str, Any]:
    study_dir = _resolve_study_dir(cfg.root, cfg.study_id)

    meta_path = study_dir / "meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8"))

    # Canonical hash MVP: meta.json only (stable enough for TUH_CANON_001 lock)
    canon_hash = _sha256_file(meta_path)
    params_hash = _sha256_bytes(_canonical_json(cfg.params))
    run_id = compute_run_id(cfg.study_id, cfg.model_id, cfg.model_version, canon_hash, params_hash)

    out_dir = study_dir / "derived" / cfg.model_id / cfg.model_version / run_id
    _safe_mkdir(out_dir)

    # Idempotency: if manifest exists and matches, exit cleanly.
    manifest_path = out_dir / "manifest.json"
    if manifest_path.exists():
        existing = json.loads(manifest_path.read_text(encoding="utf-8"))
        if (
            existing.get("study_id") == cfg.study_id
            and existing.get("run_id") == run_id
            and existing.get("canon_hash") == canon_hash
            and existing.get("params_hash") == params_hash
            and existing.get("model_id") == cfg.model_id
            and existing.get("model_version") == cfg.model_version
        ):
            return {"status": "noop", "study_dir": str(study_dir), "run_id": run_id, "out_dir": str(out_dir)}

    arr = _open_signals(study_dir)
    means, stds = _stats_features(arr, win_samples=int(cfg.params.get("win_samples", 4096)))

    segments = _heuristic_segments(means, stds)

    segments_doc = {
        "schema_version": "cplane.segments.v1",
        "study_id": cfg.study_id,
        "run_id": run_id,
        "segments": segments,
    }
    artifacts_doc = {
        "schema_version": "cplane.artifacts.v1",
        "study_id": cfg.study_id,
        "run_id": run_id,
        "artifacts": [],
    }
    annotations_doc = {
        "schema_version": "cplane.annotations.v1",
        "study_id": cfg.study_id,
        "run_id": run_id,
        "annotations": [],
    }
    manifest_doc = {
        "schema_version": "cplane.manifest.v1",
        "study_id": cfg.study_id,
        "run_id": run_id,
        "model_id": cfg.model_id,
        "model_version": cfg.model_version,
        "canon_hash": canon_hash,
        "params_hash": params_hash,
        "meta_hint": {"fs": meta.get("sampling_rate_hz") or meta.get("sfreq") or meta.get("fs")},
        "files": ["segments.json", "artifacts.json", "annotations.json", "manifest.json"],
    }

    _atomic_write_text(out_dir / "segments.json", json.dumps(segments_doc, indent=2))
    _atomic_write_text(out_dir / "artifacts.json", json.dumps(artifacts_doc, indent=2))
    _atomic_write_text(out_dir / "annotations.json", json.dumps(annotations_doc, indent=2))
    _atomic_write_text(out_dir / "manifest.json", json.dumps(manifest_doc, indent=2))

    # Update pointer atomically
    current_path = study_dir / "derived" / "current.json"
    current_doc = {"model_id": cfg.model_id, "model_version": cfg.model_version, "run_id": run_id}
    _atomic_write_text(current_path, json.dumps(current_doc, indent=2))

    return {"status": "published", "study_dir": str(study_dir), "run_id": run_id, "out_dir": str(out_dir)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Repo root or data root containing studies/")
    ap.add_argument("--study-id", default="TUH_CANON_001")
    ap.add_argument("--model-id", default="stats")
    ap.add_argument("--model-version", default="0.1.0")
    ap.add_argument("--params", default="{}", help='JSON string, e.g. \'{"win_samples":4096}\'')
    args = ap.parse_args()

    cfg = PublishConfig(
        root=Path(args.root).resolve(),
        study_id=args.study_id,
        model_id=args.model_id,
        model_version=args.model_version,
        params=json.loads(args.params),
    )
    res = publish(cfg)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
