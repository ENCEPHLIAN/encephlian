import argparse
import json
from pathlib import Path
from typing import Any, Dict

from apps.infer.core.run_id import canon_hash, params_hash, compute_run_id, canonical_json, sha256_bytes

def write_bytes_atomic(path: Path, b: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(b)
    tmp.replace(path)

def write_json_atomic(path: Path, obj: Dict[str, Any]) -> None:
    b = canonical_json(obj) + b"\n"
    write_bytes_atomic(path, b)

def main() -> int:
    ap = argparse.ArgumentParser(prog="enceph_infer")
    ap.add_argument("--root", default=".", help="Repo-relative root (default: .)")
    ap.add_argument("--study-id", required=True)
    ap.add_argument("--study-dir", default=None, help="Optional explicit study dir. If omitted: <root>/data/studies/<study-id>")
    ap.add_argument("--model-id", required=True)
    ap.add_argument("--model-version", required=True)
    ap.add_argument("--params", default="{}", help='JSON string, e.g. "{}"')
    ap.add_argument("--set-current", action="store_true", help="Write derived/current.json pointer for this run")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    if args.study_dir:
        study_dir = Path(args.study_dir).resolve()
    else:
        study_dir = root / "data" / "studies" / args.study_id

    # Compute hashes
    ch = canon_hash(study_dir)
    params_obj = json.loads(args.params)
    ph = params_hash(params_obj)
    rid = compute_run_id(args.study_id, args.model_id, args.model_version, ch["canon_hash"], ph)

    derived_root = study_dir / "derived"
    run_dir = derived_root / args.model_id / args.model_version / rid
    manifest_path = run_dir / "manifest.json"
    segments_path = run_dir / "segments.json"

    manifest = {
        "schema_version": "iplane.manifest.v1",
        "study_id": args.study_id,
        "model_id": args.model_id,
        "model_version": args.model_version,
        "run_id": rid,
        "canon_hash": ch,
        "params": params_obj,
        "params_hash": ph,
    }

    segments = {
        "schema_version": "cplane.segments.v1",
        "study_id": args.study_id,
        "run_id": rid,
        "segments": [
            {"start_sec": 0.0, "end_sec": None, "label": "placeholder", "confidence": 1.0}
        ],
    }

    def expected_bytes(obj: Dict[str, Any]) -> bytes:
        return canonical_json(obj) + b"\n"

    # Idempotency: if already exists, verify deterministic bytes
    if manifest_path.exists() and segments_path.exists():
        if manifest_path.read_bytes() != expected_bytes(manifest):
            raise SystemExit(f"Idempotency FAIL: manifest differs for existing run_id {rid}")
        if segments_path.read_bytes() != expected_bytes(segments):
            raise SystemExit(f"Idempotency FAIL: segments differs for existing run_id {rid}")
        print(f"OK (idempotent): run_id={rid}")
    else:
        write_json_atomic(manifest_path, manifest)
        write_json_atomic(segments_path, segments)
        out_hash = sha256_bytes(manifest_path.read_bytes() + segments_path.read_bytes())
        print(f"OK: run_id={rid}")
        print(f"run_dir={run_dir}")
        print(f"out_sha256={out_hash}")

    # Option B: write deterministic pointer file
    if args.set_current:
        current = {
            "schema_version": "iplane.current.v1",
            "study_id": args.study_id,
            "model_id": args.model_id,
            "model_version": args.model_version,
            "run_id": rid,
            "canon_hash": ch["canon_hash"],
            "params_hash": ph,
        }
        current_path = derived_root / "current.json"
        # idempotent pointer update: only rewrite if different bytes
        b = expected_bytes(current)
        if current_path.exists() and current_path.read_bytes() == b:
            print("OK (idempotent): current.json unchanged")
        else:
            write_bytes_atomic(current_path, b)
            print(f"OK: set current -> {current_path}")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
