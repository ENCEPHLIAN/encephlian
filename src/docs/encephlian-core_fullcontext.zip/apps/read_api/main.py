from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np
import zarr
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response

app = FastAPI()

EXPOSE_HEADERS = [
    "x-eeg-study-id",
    "x-eeg-start",
    "x-eeg-length",
    "x-eeg-sample-rate-hz",
    "x-eeg-channel-count",
    "x-eeg-channel-ids",
    "x-eeg-samples-per-channel",
    "x-eeg-layout",
    "x-eeg-dtype",
    "x-eeg-unit",
    "x-eeg-content-sha256",
    "x-eeg-server-ms",
    "etag",
    "cache-control",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=EXPOSE_HEADERS,
)

def require_key(x_api_key: Optional[str]) -> None:
    expected = (os.getenv("ENCEPH_API_KEY") or os.getenv("ENCEPH_READ_API_KEY") or "").strip()
    if not expected:
        raise HTTPException(status_code=500, detail="ENCEPH_API_KEY not set")
    if (x_api_key or "").strip() != expected:
        raise HTTPException(status_code=401, detail="invalid api key")

def data_root() -> Path:
    # local dev can set ".", container can set "/app"
    return Path(os.environ.get("ENCEPH_DATA_ROOT", ".")).resolve()

def study_dir(study_id: str) -> Path:
    # MVP lock stays, but support both directory layouts.
    if study_id != "TUH_CANON_001":
        raise HTTPException(status_code=404, detail="Unknown study_id (MVP lock: TUH_CANON_001)")

    dr = data_root()

    # Prefer actual existing paths (this removes 404 friction)
    candidates = [
        dr / "studies" / study_id,
        dr / "data" / "studies" / study_id,
        dr / "data" / study_id,
        dr / study_id,
    ]
    for p in candidates:
        if (p / "meta.json").exists():
            return p

    # If none exist, throw a precise error
    raise HTTPException(
        status_code=404,
        detail=f"meta.json not found for {study_id} under ENCEPH_DATA_ROOT={dr}",
    )

def read_text(p: Path) -> str:
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"{p.name} not found")
    return p.read_text(encoding="utf-8")

def read_json_path(p: Path, label: str) -> Any:
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"{label} not found")
    try:
        return json.loads(read_text(p))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"invalid json for {label}: {e}")

def read_meta(study_id: str) -> Dict[str, Any]:
    return read_json_path(study_dir(study_id) / "meta.json", "meta.json")

def open_signals_array(study_id: str) -> zarr.Array:
    zp = study_dir(study_id) / "signals.zarr"
    if not zp.exists():
        raise HTTPException(status_code=404, detail="signals.zarr not found")
    g = zarr.open_group(str(zp), mode="r")
    if "signals" in g:
        return g["signals"]
    arrays = list(g.arrays())
    if not arrays:
        raise HTTPException(status_code=500, detail="signals.zarr contains no arrays")
    return arrays[0][1]

def read_json_asset(study_id: str, name: str) -> Any:
    p = study_dir(study_id) / f"{name}.json"
    return read_json_path(p, f"{name}.json")

# ---- Option-B derived pointer ----
def read_current_pointer(study_id: str) -> Optional[Dict[str, Any]]:
    p = study_dir(study_id) / "derived" / "current.json"
    if not p.exists():
        return None
    cur = read_json_path(p, "derived/current.json")
    if not isinstance(cur, dict):
        return None
    for k in ("model_id", "model_version", "run_id"):
        if k not in cur:
            return None
    return cur

def _derived_file(study_id: str, filename: str) -> Optional[Path]:
    cur = read_current_pointer(study_id)
    if not cur:
        return None
    return (
        study_dir(study_id)
        / "derived"
        / str(cur["model_id"])
        / str(cur["model_version"])
        / str(cur["run_id"])
        / filename
    )

def read_segments_option_b(study_id: str) -> Any:
    p = _derived_file(study_id, "segments.json")
    if p and p.exists():
        return read_json_path(p, "segments.json (derived/current.json)")
    return {"schema_version": "cplane.segments.v1", "study_id": study_id, "run_id": None, "segments": []}

def read_artifacts_option_b(study_id: str) -> Any:
    p = _derived_file(study_id, "artifacts.json")
    if p and p.exists():
        return read_json_path(p, "artifacts.json (derived/current.json)")
    # fallback to canonical asset but normalized shape
    canon = read_json_asset(study_id, "artifacts")
    if isinstance(canon, dict) and "schema_version" in canon:
        return canon
    if isinstance(canon, list):
        return {"schema_version": "cplane.artifacts.v1", "study_id": study_id, "run_id": None, "artifacts": canon}
    return {"schema_version": "cplane.artifacts.v1", "study_id": study_id, "run_id": None, "artifacts": []}

def read_annotations_option_b(study_id: str) -> Any:
    p = _derived_file(study_id, "annotations.json")
    if p and p.exists():
        return read_json_path(p, "annotations.json (derived/current.json)")
    canon = read_json_asset(study_id, "annotations")
    if isinstance(canon, dict) and "schema_version" in canon:
        return canon
    if isinstance(canon, list):
        return {"schema_version": "cplane.annotations.v1", "study_id": study_id, "run_id": None, "annotations": canon}
    return {"schema_version": "cplane.annotations.v1", "study_id": study_id, "run_id": None, "annotations": []}

# ---- Endpoints ----
@app.get("/health")
def health():
    return {"ok": True, "root": str(data_root())}

@app.get("/studies/{study_id}/meta")
def get_meta(
    study_id: str,
    root: str = Query("."),
    x_api_key: Optional[str] = Header(None, alias="X-API-KEY"),
    x_api_key2: Optional[str] = Header(None, alias="x-api-key"),
):
    require_key(x_api_key2 or x_api_key)
    return JSONResponse(read_meta(study_id))

@app.get("/studies/{study_id}/chunk.bin")
def get_chunk_bin(
    study_id: str,
    start: int = Query(..., ge=0),
    length: int = Query(..., ge=1),
    root: str = Query("."),
    x_api_key: Optional[str] = Header(None, alias="X-API-KEY"),
    x_api_key2: Optional[str] = Header(None, alias="x-api-key"),
):
    require_key(x_api_key2 or x_api_key)

    t0 = time.time()
    meta = read_meta(study_id)
    arr = open_signals_array(study_id)

    n_ch = int(arr.shape[0])
    n_samp = int(arr.shape[1])

    end = start + length
    if end > n_samp:
        raise HTTPException(status_code=416, detail="requested range out of bounds")

    chunk = np.asarray(arr[:, start:end], dtype=np.float32)
    body = chunk.tobytes(order="C")

    sr = float(
        meta.get("sampling_rate_hz")
        or meta.get("sample_rate_hz")
        or meta.get("sfreq")
        or meta.get("fs")
        or 0.0
    )
    ch_ids = meta.get("channel_ids") or meta.get("channels") or []
    if isinstance(ch_ids, list):
        ch_ids = [str(x) for x in ch_ids]
    else:
        ch_ids = []

    sha256 = hashlib.sha256(body).hexdigest()
    server_ms = int((time.time() - t0) * 1000)

    headers = {
        "x-eeg-study-id": study_id,
        "x-eeg-start": str(int(start)),
        "x-eeg-length": str(int(chunk.shape[1])),
        "x-eeg-sample-rate-hz": str(sr),
        "x-eeg-channel-count": str(n_ch),
        "x-eeg-channel-ids": ",".join(ch_ids),
        "x-eeg-samples-per-channel": str(int(chunk.shape[1])),
        "x-eeg-layout": "planar",
        "x-eeg-dtype": "f32le",
        "x-eeg-unit": "uV",
        "x-eeg-content-sha256": sha256,
        "x-eeg-server-ms": str(server_ms),
        "etag": sha256,
        "cache-control": "public, max-age=31536000, immutable",
    }

    return Response(content=body, media_type="application/octet-stream", headers=headers)

@app.get("/studies/{study_id}/segments")
def get_segments(
    study_id: str,
    root: str = Query("."),
    x_api_key: Optional[str] = Header(None, alias="X-API-KEY"),
    x_api_key2: Optional[str] = Header(None, alias="x-api-key"),
):
    require_key(x_api_key2 or x_api_key)
    return JSONResponse(read_segments_option_b(study_id))

@app.get("/studies/{study_id}/artifacts")
def get_artifacts(
    study_id: str,
    root: str = Query("."),
    x_api_key: Optional[str] = Header(None, alias="X-API-KEY"),
    x_api_key2: Optional[str] = Header(None, alias="x-api-key"),
):
    require_key(x_api_key2 or x_api_key)
    return JSONResponse(read_artifacts_option_b(study_id))

@app.get("/studies/{study_id}/annotations")
def get_annotations(
    study_id: str,
    root: str = Query("."),
    x_api_key: Optional[str] = Header(None, alias="X-API-KEY"),
    x_api_key2: Optional[str] = Header(None, alias="x-api-key"),
):
    require_key(x_api_key2 or x_api_key)
    return JSONResponse(read_annotations_option_b(study_id))
