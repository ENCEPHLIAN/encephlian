from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import zarr

# NOTE: Determinism fix:
# Zarr chunk files were differing run-to-run while decompressed data matched.
# Root cause: compressor/chunk encoding nondeterminism (often multithreaded blosc).
# MVP choice: write canonical tensor with compressor=None for byte-stable output.
CONVERTER_ID = "cplane.edf"
CONVERTER_VERSION = "0.2.0"


def _utc_now_iso() -> str:
    # Keep created_utc in meta (informational). If you want FULL byte determinism
    # including meta.json, replace this with a deterministic surrogate.
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def _ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def build_paths(out_dir: Path) -> dict[str, Path]:
    return {
        "out_dir": out_dir,
        "tensor_path": out_dir / "tensor.zarr",
        "meta_path": out_dir / "meta.json",
        "audit_path": out_dir / "audit.jsonl",
    }


def write_audit(audit_path: Path, stage: str, status: str, extra: dict[str, Any] | None = None) -> None:
    """
    Audit is useful for debugging. But wall-clock timestamps and absolute paths
    break determinism. So we write a stable event schema (no ts).
    """
    event: dict[str, Any] = {"stage": stage, "status": status}
    if extra:
        # Avoid absolute paths in audit for determinism
        clean = {}
        for k, v in extra.items():
            if isinstance(v, str) and ("/" in v or "\\" in v):
                clean[k] = Path(v).name
            else:
                clean[k] = v
        event.update(clean)

    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, sort_keys=True) + "\n")


def write_tensor_zarr(tensor_path: Path, X: np.ndarray, chunk_time: int = 16384) -> None:
    """
    Writes X to tensor.zarr deterministically.

    Key determinism decisions:
    - Ensure X is C-contiguous float32.
    - Explicit compressor=None (no compression) so chunk bytes are stable.
    - Explicit chunks so layout is stable.
    """
    tensor_path = Path(tensor_path)
    if tensor_path.exists():
        # zarr.group(overwrite=True) should handle it, but be explicit
        pass

    X = np.asarray(X, dtype=np.float32, order="C")  # (n_channels, n_samples)

    n_channels, n_samples = int(X.shape[0]), int(X.shape[1])
    chunks = (min(n_channels, 32), min(n_samples, int(chunk_time)))

    store = zarr.DirectoryStore(str(tensor_path))
    root = zarr.group(store=store, overwrite=True)

    arr = root.create_dataset(
        "X",
        shape=X.shape,
        chunks=chunks,
        dtype="f4",
        overwrite=True,
        compressor=None,          # <-- determinism fix
        order="C",
    )

    # Zarr writes deterministically when compression is disabled
    arr[:] = X


def write_meta_json(meta_path: Path, meta: dict[str, Any]) -> None:
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def cmd_run(args: argparse.Namespace) -> int:
    from libs.canonical.vendors.natus import NatusInput  # safe even for TUH EDF in your repo
    from libs.canonical.vendors.natus import load_edf_as_canonical  # your existing loader

    out_root = Path(args.out).expanduser().resolve()
    study_root = out_root / "studies" / args.study_id / "canonical" / "v1"
    _ensure_dir(study_root)

    paths = build_paths(study_root)

    write_audit(paths["audit_path"], "READ_INPUT", "START", {"input": str(args.input)})

    # --- Load + canonicalize (your existing logic) ---
    # This function is assumed to return:
    #   X: np.ndarray float32 (n_channels, n_samples)
    #   meta: dict including n_channels, n_samples, sampling_rate_hz, channel_map, etc.
    X, meta = load_edf_as_canonical(
        NatusInput(
            input_path=Path(args.input).expanduser().resolve(),
            study_id=args.study_id,
        )
    )

    # Ensure meta contract keys exist
    meta.setdefault("converter_id", CONVERTER_ID)
    meta.setdefault("converter_version", CONVERTER_VERSION)
    meta.setdefault("canonical_version", "1.0.0")

    # Keep created_utc in meta (ok), but audit remains deterministic.
    meta.setdefault("created_utc", _utc_now_iso())

    write_audit(paths["audit_path"], "WRITE_TENSOR", "START")
    write_tensor_zarr(paths["tensor_path"], X)
    write_audit(paths["audit_path"], "WRITE_TENSOR", "OK", {"tensor": str(paths["tensor_path"])})

    write_audit(paths["audit_path"], "WRITE_META", "START")
    write_meta_json(paths["meta_path"], meta)
    write_audit(paths["audit_path"], "WRITE_META", "OK", {"meta": str(paths["meta_path"])})

    print(str(study_root))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="cplane", description="Encephlian C-plane CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    run = sub.add_parser("run", help="Canonicalize EEG into canonical/v1")
    run.add_argument("--input", required=True)
    run.add_argument("--study-id", required=True)
    run.add_argument("--out", default=".")
    run.add_argument("--vendor", default="tuh")
    run.add_argument("--format", default="edf")
    run.set_defaults(func=cmd_run)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
