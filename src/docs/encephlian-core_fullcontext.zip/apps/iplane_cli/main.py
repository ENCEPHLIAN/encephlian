from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np
import zarr

from libs.common.determinism import deterministic_created_utc


# -----------------------------
# Helpers: IO + determinism
# -----------------------------
def _write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def _open_any_zarr_array(zarr_dir: Path, preferred: str) -> zarr.Array:
    """
    Open a zarr group and return preferred array if present; else first array.
    """
    g = zarr.open_group(str(zarr_dir), mode="r")
    if preferred in g:
        return g[preferred]
    arrays = list(g.arrays())
    if not arrays:
        raise SystemExit(f"zarr group has no arrays: {zarr_dir}")
    return arrays[0][1]


def _open_signals_array_from_study(study_dir: Path) -> zarr.Array:
    """
    Supports BOTH layouts:
      A) legacy MVP: studies/<id>/signals.zarr (array name 'signals' or first)
      B) canonical v1: studies/<id>/canonical/v1/tensor.zarr (array name 'X' or first)
    """
    p1 = study_dir / "signals.zarr"
    if p1.exists():
        return _open_any_zarr_array(p1, preferred="signals")

    p2 = study_dir / "canonical" / "v1" / "tensor.zarr"
    if p2.exists():
        return _open_any_zarr_array(p2, preferred="X")

    raise SystemExit(f"missing signals source: {p1} OR {p2}")


def _read_meta_from_study(study_dir: Path) -> Dict[str, Any]:
    """
    Supports BOTH layouts:
      A) studies/<id>/meta.json
      B) studies/<id>/canonical/v1/meta.json
    """
    p1 = study_dir / "meta.json"
    if p1.exists():
        return json.loads(p1.read_text(encoding="utf-8"))

    p2 = study_dir / "canonical" / "v1" / "meta.json"
    if p2.exists():
        return json.loads(p2.read_text(encoding="utf-8"))

    raise SystemExit(f"missing meta.json: {p1} OR {p2}")


def _stable_json_string(obj: Any) -> str:
    """
    Canonical JSON encoding for hashing. Sort keys for stability.
    """
    return json.dumps(obj, separators=(",", ":"), sort_keys=True)


def _sha256_hexdigest_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _sha256_signals(arr: zarr.Array, block_samples: int = 25000) -> str:
    """
    Deterministic streaming hash over (n_channels, n_samples).
    Reads in time blocks to avoid loading the full tensor.
    """
    if len(arr.shape) != 2:
        raise SystemExit(f"expected 2D signals array (C,T), got shape={arr.shape}")

    n_ch = int(arr.shape[0])
    n_samp = int(arr.shape[1])

    h = hashlib.sha256()
    # include shape to avoid collisions across reshapes
    h.update(f"{n_ch}x{n_samp}".encode("utf-8"))

    # stream over time axis
    t = 0
    while t < n_samp:
        end = min(n_samp, t + int(block_samples))
        x = np.asarray(arr[:, t:end], dtype=np.float32, order="C")
        h.update(x.tobytes(order="C"))
        t = end

    return h.hexdigest()


def _compute_run_id(
    *,
    signals_sha256: str,
    model_name: str,
    model_version: str,
    config_obj: Dict[str, Any],
) -> str:
    payload = {
        "signals_sha256": signals_sha256,
        "model_name": model_name,
        "model_version": model_version,
        "config": config_obj,
    }
    canon = _stable_json_string(payload).encode("utf-8")
    return _sha256_hexdigest_bytes(canon)


# -----------------------------
# Phase 3: I-plane writeback
# -----------------------------
def _write_run_outputs(
    *,
    study_dir: Path,
    run_id: str,
    signals_sha256: str,
    model_name: str,
    model_version: str,
    config_obj: Dict[str, Any],
    publish_latest: bool,
) -> Path:
    """
    Writes derived outputs into:
      studies/<id>/derived/runs/<run_id>/*.json
    and optionally publishes latest copies into:
      studies/<id>/{artifacts,annotations,segments}.json
      studies/<id>/derived/latest.json
    """
    created_utc = deterministic_created_utc(run_id)

    runs_dir = study_dir / "derived" / "runs" / run_id
    runs_dir.mkdir(parents=True, exist_ok=True)

    # ---- Provenance ----
    run_obj = {
        "schema": "enceph.derived.run.v1",
        "run_id": run_id,
        "created_utc": created_utc,
        "input": {
            "signals_sha256": signals_sha256,
        },
        "model": {
            "name": model_name,
            "version": model_version,
        },
        "config": config_obj,
        "outputs": {
            "artifacts": "artifacts.json",
            "annotations": "annotations.json",
            "segments": "segments.json",
        },
        "idempotency": "same inputs => same run_id => same bytes",
    }
    _write_json(runs_dir / "run.json", run_obj)

    # ---- Outputs (MVP: stub but schema-stable) ----
    # You can swap these generators later with real inference; keep JSON shape stable.
    artifacts = {
        "schema": "enceph.artifacts.v1",
        "run_id": run_id,
        "created_utc": created_utc,
        "items": [],  # intervals, artifact types, etc.
    }
    annotations = {
        "schema": "enceph.annotations.v1",
        "run_id": run_id,
        "created_utc": created_utc,
        "items": [],  # events/markers
    }
    segments = {
        "schema": "enceph.segments.v1",
        "run_id": run_id,
        "created_utc": created_utc,
        "items": [],  # e.g., sleep staging / seizure segments
    }

    _write_json(runs_dir / "artifacts.json", artifacts)
    _write_json(runs_dir / "annotations.json", annotations)
    _write_json(runs_dir / "segments.json", segments)

    if publish_latest:
        # pointer file
        latest = {
            "schema": "enceph.derived.latest.v1",
            "run_id": run_id,
            "created_utc": created_utc,
        }
        _write_json(study_dir / "derived" / "latest.json", latest)

        # publish compatibility copies for Read API (keeps existing endpoints unchanged)
        _write_json(study_dir / "artifacts.json", artifacts)
        _write_json(study_dir / "annotations.json", annotations)
        _write_json(study_dir / "segments.json", segments)

    return runs_dir


def cmd_writeback(args: argparse.Namespace) -> int:
    out = Path(args.out).expanduser().resolve()
    study_dir = out / "studies" / args.study_id

    if not study_dir.exists():
        raise SystemExit(f"missing study dir: {study_dir}")

    meta = _read_meta_from_study(study_dir)
    arr = _open_signals_array_from_study(study_dir)

    # Prefer existing meta source sha when present; otherwise compute a full streaming hash
    src = meta.get("source") if isinstance(meta.get("source"), dict) else {}
    signals_sha256 = str(src.get("sha256") or "").strip()
    if not signals_sha256:
        signals_sha256 = _sha256_signals(arr, block_samples=int(args.block_samples))

    config_obj: Dict[str, Any]
    if args.config_json:
        config_obj = json.loads(args.config_json)
        if not isinstance(config_obj, dict):
            raise SystemExit("--config-json must be a JSON object")
    else:
        config_obj = {"mode": "stub", "note": "Phase 3 MVP writeback"}

    run_id = _compute_run_id(
        signals_sha256=signals_sha256,
        model_name=args.model_name,
        model_version=args.model_version,
        config_obj=config_obj,
    )

    runs_dir = _write_run_outputs(
        study_dir=study_dir,
        run_id=run_id,
        signals_sha256=signals_sha256,
        model_name=args.model_name,
        model_version=args.model_version,
        config_obj=config_obj,
        publish_latest=bool(args.publish_latest),
    )

    print(str(runs_dir))
    return 0


# -----------------------------
# Existing (kept): legacy stub derivatives under canonical/v1
# -----------------------------
def cmd_run(args: argparse.Namespace) -> int:
    """
    Legacy subcommand kept for compatibility. Does not publish to study root.
    """
    out = Path(args.out).expanduser().resolve()
    study_root = out / "studies" / args.study_id
    v1 = study_root / "canonical" / "v1"
    meta_path = v1 / "meta.json"
    if not meta_path.exists():
        raise SystemExit(f"missing canonical meta.json at: {meta_path}")

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    X = _open_any_zarr_array(v1 / "tensor.zarr", preferred="X")

    deriv = v1 / "derivatives"
    deriv.mkdir(parents=True, exist_ok=True)

    sig = str((meta.get("source") or {}).get("sha256") or "")
    created = deterministic_created_utc(sig)

    nb = {
        "task": "normal_abnormal",
        "method": "stub_rms_v0",
        "score_abnormal": 1.0,
        "decision": "abnormal",
        "input_signature": sig,
        "created_utc": created,
    }
    _write_json(deriv / "normal_abnormal.json", nb)

    n_samp = int(X.shape[1])
    mask_dir = deriv / "artifact_mask.zarr"
    zroot = zarr.open(mask_dir, mode="a")

    if "mask" in getattr(zroot, "array_keys", lambda: [])():
        arr = zroot["mask"]
        if arr.shape != (n_samp,):
            del zroot["mask"]
            arr = zroot.create_dataset("mask", shape=(n_samp,), dtype="u1", chunks=(min(25000, n_samp),), overwrite=True)
    else:
        arr = zroot.create_dataset("mask", shape=(n_samp,), dtype="u1", chunks=(min(25000, n_samp),), overwrite=True)

    arr[:] = 0
    zroot.attrs["created_utc"] = created
    zroot.attrs["input_signature"] = sig
    zroot.attrs["method"] = "stub_all_clean_v0"

    print(str(deriv))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="iplane", description="Encephlian I-plane CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    run = sub.add_parser("run", help="Legacy stub derivatives under canonical/v1")
    run.add_argument("--study-id", required=True)
    run.add_argument("--out", default=".")
    run.set_defaults(func=cmd_run)

    wb = sub.add_parser("writeback", help="Phase 3: write derived JSON back into C-plane deterministically")
    wb.add_argument("--study-id", required=True)
    wb.add_argument("--out", default=".")
    wb.add_argument("--model-name", default="stub-model")
    wb.add_argument("--model-version", default="0.0.0")
    wb.add_argument("--config-json", default="", help='JSON object string (e.g. \'{"threshold":0.5}\')')
    wb.add_argument("--publish-latest", action="store_true", help="Publish latest outputs into study root for Read API")
    wb.add_argument("--block-samples", default="25000", help="Streaming hash block size (samples per channel)")
    wb.set_defaults(func=cmd_writeback)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
